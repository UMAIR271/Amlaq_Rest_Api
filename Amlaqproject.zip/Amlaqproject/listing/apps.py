from django.apps import AppConfig


class ListingConfig(AppConfig):
    name = 'listing'
